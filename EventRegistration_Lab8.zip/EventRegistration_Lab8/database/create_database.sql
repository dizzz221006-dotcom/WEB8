-- Run this script while connected to the default 'postgres' database.
CREATE DATABASE event_db;
