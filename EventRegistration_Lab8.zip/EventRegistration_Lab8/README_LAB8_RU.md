# Event Registration API — Lab 8 (Spring Data JPA + PostgreSQL)

## Требования
- JDK 17
- PostgreSQL (и pgAdmin или psql)
- IntelliJ IDEA

## 1. Создать базу
В pgAdmin подключитесь к серверу PostgreSQL. Нажмите правой кнопкой на Databases -> Create -> Database... и назовите базу `event_db`.
Либо подключитесь через Query Tool к базе `postgres` и выполните `CREATE DATABASE event_db;`.
Не запускайте этот SQL повторно, если база уже существует.

## 2. Указать пароль PostgreSQL
В `src/main/resources/application.properties`:
- `DB_USER` по умолчанию `postgres`
- `DB_PASSWORD` по умолчанию `change_me` — замените на пароль своего локального пользователя PostgreSQL, или задайте переменные окружения `DB_USER` и `DB_PASSWORD`.
- `DB_URL` по умолчанию `jdbc:postgresql://localhost:5432/event_db`.

Не отправляйте пароль в GitHub и не включайте его в скриншоты.

## 3. Запустить IntelliJ IDEA
Откройте папку проекта `EventRegistration_Lab8` как Gradle project. Убедитесь, что выбран JDK 17. Разрешите IntelliJ загрузить Gradle dependencies. Затем запустите `EventRegistrationApplication`.

При успешном запуске Hibernate автоматически создаст таблицу `events` в базе `event_db`.

## 4. Проверить API
Базовый адрес: `http://localhost:8080`.

### Создать событие (POST)
`POST http://localhost:8080/api/events`
Заголовок: `Content-Type: application/json`
```json
{
  "title": "Java Workshop",
  "location": "Almaty"
}
```
Ожидается HTTP 201 и JSON с автоматически созданным `id`.

### Прочитать
- `GET http://localhost:8080/api/events`
- `GET http://localhost:8080/api/events/1` (подставьте фактический id)
- `GET http://localhost:8080/api/events?title=java`

### Изменить (PUT)
`PUT http://localhost:8080/api/events/1`
```json
{
  "title": "Advanced Java Workshop",
  "location": "Online"
}
```
Ожидается HTTP 200. ID сохраняется.

### Удалить (DELETE)
`DELETE http://localhost:8080/api/events/1`
Ожидается HTTP 204. Для неизвестного ID — HTTP 404.

## 5. Проверить таблицу и сохранение
В pgAdmin откройте Query Tool базы `event_db` и выполните:
```sql
SELECT id, title, location FROM events;
```
Создайте событие через POST, перезапустите приложение и проверьте GET по тому же ID. Запись должна сохраниться.

## Как устроено
- `Event` — JPA-сущность, которая соответствует таблице `events`.
- `EventRepository` — `JpaRepository`, выполняет операции с БД.
- `EventService` — бизнес-логика, использует репозиторий через конструктор.
- `RegistrationController` — REST endpoints.
